package com.example.nsucpcstudent;

public class PermanentAddress {
    public String perRoad;
    public String perHouse;
    public int perPostCode;
    public String perPoliceStation;
    public String perPostOffice;
    public String perDistrict;
    public String perCountry;
}
