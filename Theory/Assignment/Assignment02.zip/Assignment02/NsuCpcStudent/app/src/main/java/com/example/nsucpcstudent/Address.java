package com.example.nsucpcstudent;

public class Address {
    public String road;
    public String house;
    public int postCode;
    public String policeStation;
    public String postOffice;
    public String district;
    public String country;
}
