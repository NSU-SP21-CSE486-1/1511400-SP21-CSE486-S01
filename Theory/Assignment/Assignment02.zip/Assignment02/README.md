#Sample Readme.md to create folder structure

[Github project link](https://github.com/NSU-SP21-CSE486-1/1511400-SP21-CSE486-S01/tree/main/Theory/Assignment/Assignment02)
